<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>API Jikan</title>
</head>
<body>
<?php

function cleanString($string) {
	$string = strtolower($string);
	$string = preg_replace("/[^a-z0-9_'\s-]/", "", $string);
	$string = preg_replace("/[\s-]+/", " ", $string);
	$string = preg_replace("/[\s_]/", " ", $string);
	return $string;
}

if(isset($_POST['mot']) && !empty($_POST['mot'])) {
	$motRecherche = urlencode(cleanString($_POST['mot']));

	/* Requête à faire pour rechercher un anime précis */
	var txtSearch = this.myTrim($("#search-input").val()).replace(" ", "%20");
	var urlS = "https://api.jikan.moe/v3/search/anime?q=" + txtSearch;
	request.open('GET', urlS);

	/* Requête à faire pour afficher les animes en vedette en ce moment */
	request.open('GET','https://api.jikan.moe/v3/top/anime/1');

	/* Requête à faire pour afficher les animes sorties lors d'une saison et année précise */
	if(isset($_POST['annee']) && !empty($_POST['annee']) && (isset($_POST['saison']) && !empty($_POST['saison'])) {
		$anneeRecherche = urlencode($_POST['annee']);
		$saisonRecherche = urlencode(cleanString($_POST['saison']));
		var urlSortieSaison = 'https://api.jikan.moe/v3/season/'+ $anneeRecherche +'/'+ $saisonRecherche;
		request.open('GET', urlSortieSaison);
	}else{
		echo "Impossible d'effectuer cette recherche, les paramètres sont incorrectes...";
	}
	
}else {
	echo "Aucune recherche effectuée...";
}

?>
</body>
</html>
